
int b() {
	return 0;
}

