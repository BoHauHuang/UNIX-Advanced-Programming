
int b();

int main() {
	b();
}

