#!/bin/sh

python3 -c 'import crypt; crypt.crypt("AdvancedProgrammingInTheUNIXEnvironment8787", "$5$chuang.cs$")'
# '$5$chuang.cs$dzOgp6GTmuUMqCOJayKyTiLvuzqTk6xZnaZs8O5Je21'

